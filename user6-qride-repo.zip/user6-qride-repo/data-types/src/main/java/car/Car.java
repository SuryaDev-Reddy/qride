package car;

public class Car {
  public enum CarType {
    UNKNOWN,
    CAR_TYPE_HATCHBACK,
    CAR_TYPE_SEDAN,
    CAR_TYPE_MINIVAN
  }
}
