-- We are programmatically inserting these values. So these are unnecessary.
-- Leaving them here in case you want to play around directly executing SQL statements
-- INSERT INTO CarStatusTable (carId, carType, carAvailability, latitude, longitude)
-- VALUES ('CAR_1', 1, 1, 12.00, 13.00);

-- Simple statement so that no errors get thrown.
show tables;
